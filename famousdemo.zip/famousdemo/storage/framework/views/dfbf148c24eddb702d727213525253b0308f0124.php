<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>Read Article </legend>
            <a href="<?php echo e(url('/')); ?>">Back</a>
    <p><h1><?php echo e($articles->title); ?></h1></p>
    <p><?php echo e($articles->description); ?></p>
</fieldset>
    </div>
    
  </div>
</div>

<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
