<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>Laravel CRUD Application</legend>
    <?php if(session()->has('msg')): ?>
    <div class="col-md-6 alert alert-success">
        <?php echo e(session('msg')); ?>

</div>
    <?php endif; ?>
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">No.</th>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col"> Option</th>
    </tr>
  </thead>
  <tbody>
      <?php if(count($articles) > 0): ?>
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <tr class="">
      <th scope="row"><?php echo e($object->id); ?></th>
      <td><?php echo e($object->title); ?></td>
      <td><?php echo e($object->description); ?></td>
      <td>
      <a href='<?php echo e(url("read/{$object->id}")); ?>' class="btn btn-primary"> Read </a>
        <a href='<?php echo e(url("edit/{$object->id}")); ?>' class="btn btn-info"> Edit </a>
        <a href='<?php echo e(url("delete/{$object->id}")); ?>' class="btn btn-danger"> Delete </a>        
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
  </tbody>
</table> 
</fieldset>
    </div>
  </div>
</div>

<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>