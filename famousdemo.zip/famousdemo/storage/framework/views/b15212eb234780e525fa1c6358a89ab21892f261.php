<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <div class="row">
    <div class="col-md-6">
    <form method="post" action="<?php echo e(url('/insert')); ?>">
    <?php echo e(csrf_field()); ?>

  <fieldset>
    <legend>Insert New </legend>
    <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger">
        <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Title</label>
      <input type="text" class="form-control" id="exampleInputEmail1" name="title" aria-describedby="emailHelp" placeholder="Enter Title">
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Description</label>
      <input type="text" class="form-control" id="exampleInputPassword1" name="description" placeholder="Description">
    </div> 
  
    <button type="submit" class="btn btn-primary">Submit</button> 
    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary"
    >Back</a>
  </fieldset>
</form>
    </div>
    
   
  </div>
</div>

<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
