<!-- footer -->
<div id="footer">
Copyright 2018, Google.com
</div>

<!-- scripts -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="{{asset('public/js/bootstrap.min.js')}}"></script>

</body>
</html>