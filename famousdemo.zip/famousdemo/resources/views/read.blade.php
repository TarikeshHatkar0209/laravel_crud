@include ('inc.header')

<div class="container">
  <div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>Read Article </legend>
            <a href="{{url('/')}}">Back</a>
    <p><h1>{{$articles->title}}</h1></p>
    <p>{{$articles->description}}</p>
</fieldset>
    </div>
    
  </div>
</div>

@include ('inc.footer')
