@include ('inc.header')

<div class="container">
  <div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>Laravel CRUD Application</legend>
    @if(session()->has('msg'))
    <div class="col-md-6 alert alert-success">
        {{session('msg')}}
</div>
    @endif
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">No.</th>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col"> Option</th>
    </tr>
  </thead>
  <tbody>
      @if(count($articles) > 0)
        @foreach($articles as $object)
    
    <tr class="">
      <th scope="row">{{$object->id}}</th>
      <td>{{$object->title}}</td>
      <td>{{$object->description}}</td>
      <td>
      <a href='{{ url("read/{$object->id}") }}' class="btn btn-primary"> Read </a>
        <a href='{{ url("edit/{$object->id}") }}' class="btn btn-info"> Edit </a>
        <a href='{{ url("delete/{$object->id}") }}' class="btn btn-danger"> Delete </a>        
    </td>
    </tr>
    @endforeach
      @endif
  </tbody>
</table> 
</fieldset>
    </div>
  </div>
</div>

@include ('inc.footer')