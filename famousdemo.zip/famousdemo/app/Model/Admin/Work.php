<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class Work extends Model
{
    //
}
