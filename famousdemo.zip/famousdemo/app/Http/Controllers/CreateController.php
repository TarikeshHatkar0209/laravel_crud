<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;

class CreateController extends Controller
{
    public function home()
    {
        $articles= Article::all();
        // echo'<pre>';
        // print_r($articles);
        // echo'</pre>';
        return view('create',['articles'=>$articles]);
    }
    public function insert(Request $request)
    {
              
       $this->validate($request,[
        'title'=>'required',
        'description'=>'required'
       ]);
      
       $articles= new Article;
       $articles->title =$request->input('title'); 
       $articles->description =$request->input('description');
       $articles->save();
       $request->session()->flash('msg', "Successfully saved!!");
       return redirect('/');
    }
    public function edit($id)
    {
        $articles= Article::find($id);
       
        return view('edit',['articles'=>$articles]);
    }
    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'title'=>'required',
            'description'=>'required'
           ]);
          $data=array(  
                'title'=> $request->input('title'), 
                'description'=> $request->input('description')
            );
           Article::where('id',$id)->update($data);      
          
           $request->session()->flash('msg', "Successfully updated!!");
           return redirect('/');
    }
    public function read($id)
    {
       
        $articles= Article::find($id);
        return view('read',['articles'=>$articles]);
    }  

    public function delete(Request $request,$id)
    {
        Article::where('id',$id)->delete(); 
        $request->session()->flash('msg', "Successfully Deleted!!"); 
        return redirect('/');
    }
}
